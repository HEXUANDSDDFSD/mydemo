#!/usr/bin/ruby

require 'xcodeproj'

project_path = File.join(File.dirname(__FILE__),"XcodeprojWork.xcodeproj")
project = Xcodeproj::Project.open(project_path)
target = project.targets.first

entity_base_path = "Entity"

unless File.exist?(entity_base_path)
	Dir.mkdir(entity_base_path)
end

my_group = project.main_group.find_subpath(entity_base_path)

if my_group.nil?
	project.main_group.new_group(entity_base_path, entity_base_path)
	my_group = project.main_group.find_subpath(entity_base_path)
end

def addFileWithContent(target,group,basePath,fileName,content)
	new_file = File.join(basePath,fileName)

	unless File.exist?(new_file);
		file = File.new(new_file,'w');
		file.close;
		fileReference = group.new_reference(fileName)
		target.add_file_references([fileReference]);
		target.source_build_phase.add_file_reference(fileReference, true)
	end

	file = File.open(new_file,'w')
	file.puts(content)
	file.close
	
end

fileName = "FourthEntity"
addFileWithContent(target,my_group,entity_base_path,fileName + '.h',
	"\n\n#import <Foundation/Foundation.h>\n\n\n@interface #{fileName} : NSObject\n\n\n@end")
addFileWithContent(target,my_group,entity_base_path,fileName + '.m',
	"\n\n#import \"#{fileName}.h\" \n\n\n@implementation #{fileName}\n\n\n@end")

project.save

