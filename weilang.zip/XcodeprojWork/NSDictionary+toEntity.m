//
//  NSDictionary+toEntity.m
//  XcodeprojWork
//
//  Created by hexuan on 2017/6/18.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import "NSDictionary+toEntity.h"

@implementation NSDictionary (toEntity)

- (NSDictionary *)testForEntityWithRootClassName:(NSString *)className{
    NSMutableArray *propertyList = [NSMutableArray array];
    NSMutableDictionary *propertyDic = [NSMutableDictionary dictionary];
    NSMutableArray *headFileList = [NSMutableArray array];
    
    for (NSString *key in [self allKeys]) {
        id value = [self objectForKey:key];
        if ([value isKindOfClass:[NSDictionary class]]) {
             [propertyDic addEntriesFromDictionary:[value testForEntityWithRootClassName:key]];
            NSString *property = [NSString stringWithFormat:@"@property (nonatomic, copy) %@* %@;", [self capitalizeString:key],key];
            [propertyList addObject:property];
            [headFileList addObject:[NSString stringWithFormat:@"#import \"%@.h\"", [self capitalizeString:key]]];
        }
        else if([value isKindOfClass:[NSArray class]]){
            NSString *showKey = key;
            if ([value count] > 0 && [value[0] isKindOfClass:[NSDictionary class]]) {
                if ([key hasSuffix:@"s"]) {
                    showKey = [key substringToIndex:key.length - 1];
                }
                else if([key hasSuffix:@"List"]) {
                    showKey = [key substringToIndex:key.length - 4];
                }
               [propertyDic addEntriesFromDictionary:[value[0] testForEntityWithRootClassName:showKey]]  ;
            }
            NSString *property = [NSString stringWithFormat:@"@property (nonatomic, copy) NSArray<%@ *> *%@;", [self capitalizeString:showKey],key];
            [propertyDic setValue:propertyList forKey:[self capitalizeString:className]];
            [propertyList addObject:property];
            [headFileList addObject:[NSString stringWithFormat:@"#import \"%@.h\"", [self capitalizeString:showKey]]];
        }
        else {
            NSString *property = [NSString stringWithFormat:@"@property (nonatomic, copy) NSString *%@;", key];
            [propertyList addObject:property];
        }
    }
    [propertyDic setValue:@{@"headFileList":headFileList, @"propertyList":propertyList} forKey:[self capitalizeString:className]];
    
    return propertyDic;
}

- (NSString *)capitalizeString:(NSString *)string {
    if (string.length == 0) {
        return nil;
    }
    NSString *headLetter = [string substringToIndex:1];
    NSMutableString *ret = [NSMutableString stringWithString:string];
    NSRange range;
    range.location = 0;
    range.length = 1;
    [ret replaceCharactersInRange:range withString:[headLetter capitalizedString]];
    
    return ret;
}

@end
