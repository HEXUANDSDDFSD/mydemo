//
//  ViewController.m
//  XcodeprojWork
//
//  Created by hexuan on 2017/6/17.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import "ViewController.h"
#import "NSDictionary+toEntity.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString *jsonStrPath = [[NSBundle mainBundle] pathForResource:@"testForContentListBySubColumnID2_Vod" ofType:@"json"];
    NSString *jsonStr = [NSString stringWithContentsOfFile:jsonStrPath
                                                  encoding:kCFStringEncodingUTF8
                                                     error:nil];
   NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:[[NSData alloc] initWithContentsOfFile:jsonStrPath]
                                    options:NSJSONReadingMutableContainers error:nil];
    NSDictionary *createClass = [jsonDic testForEntityWithRootClassName:@"MyTestEntity"];
   
        NSString *urls = @"http://127.0.0.1/OC_Auto/index.php";
    
        NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"%@", urls]];
        // 2.创建一个网络请求
        NSMutableURLRequest *request =[NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"POST";
    NSData *paraData = [NSJSONSerialization dataWithJSONObject:createClass
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:nil];
    NSString *paraString = [[NSString alloc] initWithData:paraData encoding:kCFStringEncodingUTF8];
    NSLog(@"%@", paraString);
    paraString = [NSString stringWithFormat:@"createInfo=%@",paraString];
    
    [request setHTTPBody:[paraString dataUsingEncoding:kCFStringEncodingUTF8]];
        // 3.获得会话对象
        NSURLSession *session = [NSURLSession sharedSession];
        // 4.根据会话对象，创建一个Task任务：
        NSURLSessionDataTask *sessionDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
            NSLog(@"从服务器获取到数据");
            /*
             对从服务器获取到的数据data进行相应的处理：
             */        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:(NSJSONReadingMutableLeaves) error:nil];
                NSLog(@"%@", dict);
        }];
        // 5.最后一步，执行任务（resume也是继续执行）:
        [sessionDataTask resume];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
