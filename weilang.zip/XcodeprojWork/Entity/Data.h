

#import <Foundation/Foundation.h>
#import "SubColumnInfo.h"


@interface Data : NSObject

@property (nonatomic, copy) NSArray<SubColumnInfo *> *subColumnInfos;


@end
