

#import <Foundation/Foundation.h>
#import "Data.h"


@interface MyTestEntity : NSObject

@property (nonatomic, copy) NSString *status;
@property (nonatomic, copy) NSString *errorMessage;
@property (nonatomic, copy) Data* data;


@end
