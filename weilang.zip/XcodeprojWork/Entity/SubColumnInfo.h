

#import <Foundation/Foundation.h>


@interface SubColumnInfo : NSObject

@property (nonatomic, copy) NSString *subColumnID;
@property (nonatomic, copy) NSString *subColumnType;
@property (nonatomic, copy) NSString *sortInx;
@property (nonatomic, copy) NSString *subColumnName;
@property (nonatomic, copy) NSString *showFlg;


@end
