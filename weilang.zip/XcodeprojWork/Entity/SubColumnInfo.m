

#import "SubColumnInfo.h" 


@implementation SubColumnInfo


@end
