//
//  NSString+Regular.m
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/26.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import "NSString+Regular.h"

@implementation NSString (Regular)

- (NSArray<NSString *> *)arrayWithRegularString:(NSString *)regularString {
    NSRegularExpression *regularExpression =  [[NSRegularExpression alloc] initWithPattern:regularString
                                                                                   options:0 error:NULL];
    NSArray *regularExpressList = [regularExpression matchesInString:self options:0 range:NSMakeRange(0, self.length)];
    NSMutableArray *stringList = [NSMutableArray array];
    for (NSTextCheckingResult *result in regularExpressList) {
        [stringList addObject:[self substringWithRange:result.range]];
    }
    return stringList;
}

@end
