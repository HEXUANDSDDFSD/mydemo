//
//  NSString+Regular.h
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/26.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Regular)

- (NSArray<NSString *> *)arrayWithRegularString:(NSString *)regularString;

@end
