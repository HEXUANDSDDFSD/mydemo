//
//  main.m
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/20.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
