//
//  AppDelegate.h
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/20.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define kOpenFileNotification @"openfileNoti"

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

