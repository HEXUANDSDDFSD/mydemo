//
//  AppDelegate.m
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/20.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (IBAction)openFileAction:(id)sender{
    NSOpenPanel *filePanel = [NSOpenPanel openPanel];
    filePanel.allowedFileTypes = @[@"xcodeproj"];
    [filePanel beginSheetModalForWindow:nil
                      completionHandler:^(NSInteger result) {
                          if (result == NSModalResponseOK) {
                              [[NSNotificationCenter defaultCenter] postNotificationName:kOpenFileNotification object:@{@"filePath":filePanel.URL.path}];
                          }
                      }];
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
