//
//  ViewController.h
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/20.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@property (nonatomic,weak) IBOutlet NSOutlineView *fileListView;
@property (nonatomic,weak) IBOutlet NSTextView *requestExampleView;
@property (nonatomic,weak) IBOutlet NSButton *produceDicBtn;
@property (nonatomic,weak) IBOutlet NSTextView *interfaceView;
@property (nonatomic,weak) IBOutlet NSTextView *requestView;
@property (nonatomic,weak) IBOutlet NSTextView *dicView;

@end

