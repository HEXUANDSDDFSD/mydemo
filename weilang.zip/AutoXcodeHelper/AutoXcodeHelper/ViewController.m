//
//  ViewController.m
//  AutoXcodeHelper
//
//  Created by hexuan on 2017/6/20.
//  Copyright © 2017年 hexuan. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "NSString+Regular.h"

@interface OutlineFileItem : NSObject

@property (nonatomic, readonly) NSMutableArray<OutlineFileItem* > *childItemList;
@property (nonatomic, copy) NSString *fileName;
@property (nonatomic, assign) BOOL isFile;

@end

@implementation OutlineFileItem;

- (instancetype)init{
    if (self = [super init]){
        _childItemList = [NSMutableArray arrayWithCapacity:0];
    }
    return self;
}

- (id)copy {
    OutlineFileItem *ret = [super copy];
    ret.fileName = self.fileName;
    return ret;
}


@end

@interface ViewController()<NSOutlineViewDelegate,NSOutlineViewDataSource>

@end

@implementation ViewController {
    OutlineFileItem *rootItem;
    NSString *basePath;
    NSArray *nameList;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    if (self = [super initWithCoder:coder]){
        rootItem = [OutlineFileItem new];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openfileNoti:) name:kOpenFileNotification object:nil];
    }
    return self;
}

- (void)processItem:(OutlineFileItem *)item filePath:(NSString *)filePath {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *fileList = [fileManager contentsOfDirectoryAtPath:filePath error:NULL];
    for (NSString *fileName in fileList) {
        if  ([fileName containsString:@"."] && ![fileName hasSuffix:@".m"] && ![fileName hasSuffix:@".h"]){
            continue;
        }
        OutlineFileItem *fileItem = [OutlineFileItem new];
        
        if (![fileName containsString:@"."]) {
            [self processItem:fileItem filePath:[filePath stringByAppendingPathComponent:fileName]];
        }
        else {
            fileItem.isFile = YES;
        }
        
        fileItem.fileName = fileName;
        [item.childItemList addObject:fileItem];
    }
}

- (IBAction)produceDicAction:(id)sender {
    NSArray *keyValueList = nil;
    BOOL isXMLrequest;
    if (isXMLrequest = [_requestExampleView.string hasPrefix:@"<"]) {
        NSString *contentString = [self.requestExampleView.string arrayWithRegularString:@"<[^\\?][\\W\\w]+?>"][0];
        keyValueList = [contentString arrayWithRegularString:@"[a-zA-Z]+=[\"a-zA-Z-0-9]+"];
    }
    else {
        keyValueList = [self.requestExampleView.string arrayWithRegularString:@"[a-zA-Z]+=[\"a-zA-Z-0-9 :]+"];
    }
    NSMutableString *interfaceString = [NSMutableString string];
    NSMutableString *accessString = [NSMutableString string];
    NSMutableString *dicString = [NSMutableString stringWithString:@"@{"];
    for (NSString *keyValue in keyValueList) {
        NSString *key = [keyValue componentsSeparatedByString:@"="][0];
        NSString *value = [keyValue componentsSeparatedByString:@"="][1];
        [interfaceString appendFormat:@"%@:(NSString *)%@\n", key,key];
        if (isXMLrequest) {
            [accessString appendFormat:@"%@:@%@\n",key,value];
        }
        else {
            [accessString appendFormat:@"%@:@\"%@\"\n",key,value];
        }
        [dicString appendFormat:@"@\"%@\":%@,\n",key,key];
    }
    [dicString deleteCharactersInRange:NSMakeRange(dicString.length - 2, 1)];
    [dicString appendString:@"};"];
    [interfaceString replaceCharactersInRange:NSMakeRange(0, 1) withString:[[interfaceString substringToIndex:1] capitalizedString]];
    [accessString replaceCharactersInRange:NSMakeRange(0, 1) withString:[[accessString substringToIndex:1] capitalizedString]];
    _interfaceView.string = interfaceString;
    _requestView.string = accessString;
    _dicView.string = dicString;
}

- (void)openfileNoti:(NSNotification *)noti {
    basePath = [noti.object[@"filePath"] stringByDeletingLastPathComponent];
    [rootItem.childItemList removeAllObjects];
    [self processItem:rootItem filePath:basePath];
    [_fileListView reloadData];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _fileListView.backgroundColor = [NSColor whiteColor];
    _requestExampleView.font = [NSFont systemFontOfSize:16];
    _requestExampleView.string = @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\
    <GetPrograms client=\"3072707542\" channelIds=\"1401\" customerGroup=\"1\" startDateTime=\"20170611000000\" endDateTime=\"20170611141814\" account=\"760011106310\" />";
    
    //[self.fileListView reloadData];

    // Do any additional setup after loading the view.
}

- (void)viewWillLayout {
    //[super viewWillLayout];
    NSLog(@"layout");
}

- (NSInteger)outlineView:(NSOutlineView *)outlineView numberOfChildrenOfItem:(nullable id)item {
    if (item) {
        return [[item childItemList] count];
    }
    else {
        return [rootItem.childItemList count];
    }
}

- (id)outlineView:(NSOutlineView *)outlineView child:(NSInteger)index ofItem:(nullable id)item {
    if (!item){
        return [rootItem childItemList][index];
    }
    return [item childItemList][index];
}

- (BOOL)outlineView:(NSOutlineView *)outlineView isItemExpandable:(id)item {
    if (!item || [[item childItemList] count] > 0) {
        return YES;
    }
    return NO;
}


- (BOOL)outlineView:(NSOutlineView *)outlineView shouldSelectTableColumn:(nullable NSTableColumn *)tableColumn {
    return YES;
}

- (NSView *)outlineView:(NSOutlineView *)outlineView
     viewForTableColumn:(NSTableColumn *)tableColumn
                   item:(id)item {
    NSTableCellView *view = [outlineView makeViewWithIdentifier:tableColumn.identifier owner:self];
    if ([item isKindOfClass:[OutlineFileItem class]]) {
        OutlineFileItem *fileItem = item;
        if (fileItem.isFile) {
            view.imageView.image = [NSImage imageNamed:@"file.png"];
        }
        else {
            view.imageView.image = [NSImage imageNamed:@"fold_new.png"];
        }
        view.textField.stringValue = fileItem.fileName;
    }
    return view;
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
