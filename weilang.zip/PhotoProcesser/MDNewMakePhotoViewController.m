//
//  MDNewMakePhotoViewController.m
//  meimeidou
//
//  Created by Hexuan on 13-4-9.
//  Copyright (c) 2013年 meimeidou. All rights reserved.
//

#import "MDNewMakePhotoViewController.h"
#import "UIView+Additions.h"
//#import "TouchImageView.h"
#import "UIImage+Additions.h"
#import <QuartzCore/QuartzCore.h>
//#import "MYDrawContentView.h"
//#import "MmdHairChangePhoto.h"
//#import "ELCAsset.h"

////////////////////////////////////////////////////////////
#pragma MDMakePhotoBottomView -----------------------

//#define kFreeBtnTagBaseValue 'fbtb'
#define kCellBtnTagBaseValue 'cbtb'

//typedef enum {
//  MakePhoto_Type_None = 0,
//  MakePhoto_Type_Cell = 1,
//  MakePhoto_Type_Free = 2
//} eMakePhotoType;

@class MDMakePhotoBottomView;

@protocol MDMakePhotoBottomViewDelegate <NSObject>

- (void)makePhotoBottomView:(MDMakePhotoBottomView *)view didSelectedWithIndex:(int)intdex;
- (void)makePhotoBottomViewDidClickedOkBtn:(MDMakePhotoBottomView *)view;
//- (void)makePhotoBottomViewDidChangeTypeBtn:(MDMakePhotoBottomView *)view;
//- (void)makePhotoBottomView:(MDMakePhotoBottomView *)view didChooseBackgroundImageName:(NSString *)imgName;

@end

@interface MDMakePhotoBottomView : UIView {
  int photoNum;
  int selectedCellBtnTag;
  int selectedFreeBtnTag;
  CGRect cellFrame;
  CGRect freeFrame;
  int topHeight;
  //eMakePhotoType type;
  id<MDMakePhotoBottomViewDelegate> __weak delegate;
}

@property (nonatomic, weak) id<MDMakePhotoBottomViewDelegate> delegate;
//@property (nonatomic, readonly) eMakePhotoType type;
//@property (nonatomic, readonly) NSString *defaultImgName;

@end

#define kAppViewWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScreenWidth [UIScreen mainScreen].bounds.size.width

@implementation MDMakePhotoBottomView
@synthesize delegate;
//@synthesize type;

- (id)initWithPhotoNum:(int)num {
  //selectedFreeBtnTag = kFreeBtnTagBaseValue;
  
  int defaultHeight = 50;
  if (self = [super initWithFrame:CGRectMake(0, 0, kAppViewWidth, defaultHeight)]) {
    //topHeight = 30;
    selectedCellBtnTag = kCellBtnTagBaseValue;
    photoNum = num;
    self.backgroundColor = [UIColor clearColor];
    //type = MakePhoto_Type_Cell;
    [self resetSubView];
  }
  
  return self;
}

//- (eMakePhotoType)type {
//  return type;
//}

//- (NSString *)defaultImgName {
//  return [self imageNameWithIndex:0];
//}

- (void)resetSubView {
  for (UIView *view in [self subviews]) {
    [view removeFromSuperview];
  }
  
 // if (type == MakePhoto_Type_Cell) {
    int offsetX = 10;
    int offsetY = topHeight + 5;
    int buttonWith = 37;
    int intervalX = 5;
    for (int i = 0; i < 4; i++) {
      UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
      button.tag = kCellBtnTagBaseValue + i;
      [button addTarget:self action:@selector(selectCellBtnAction:) forControlEvents:UIControlEventTouchUpInside];
      [button setBackgroundImage:[UIImage imageNamed:[self imgStrWithIndex:i]] forState:UIControlStateNormal];
      UIImage *selectedImg = [UIImage imageNamed:[[self imgStrWithIndex:i] stringByAppendingString:@"_d"]];
      [button setBackgroundImage:selectedImg forState:UIControlStateHighlighted];
      [button setBackgroundImage:selectedImg forState:UIControlStateSelected];
      button.frame = CGRectMake(offsetX + (intervalX + buttonWith) * i, offsetY, buttonWith, buttonWith);
      [self addSubview:button];
      if (i == selectedCellBtnTag - kCellBtnTagBaseValue) {
        button.selected = YES;
        selectedCellBtnTag = button.tag;
        button.userInteractionEnabled = NO;
      }
    }
//  else if (type == MakePhoto_Type_Free) {
//    
//    UIScrollView *itemScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(10, topHeight, self.bounds.size.width-45, self.bounds.size.height - topHeight)];
//    for (int i = 0; i <= 5; i++) {
//      UIView *btnBgView = [[UIView alloc] initWithFrame:CGRectMake((35+8)*i, (itemScrollView.frame.size.height-35)/2+2, 35, 35)];
//      btnBgView.backgroundColor = [UIColor whiteColor];
//      
//      UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//      NSString *imgName = [NSString stringWithFormat:@"bg_0%d.jpg",i+1];
//      [btn setBackgroundImage:[UIImage imageNamed:imgName] forState:UIControlStateNormal];
//      
//      btn.frame = UIEdgeInsetsInsetRect(btnBgView.bounds, UIEdgeInsetsMake(2, 2, 2,2));
//      btn.tag = i + kFreeBtnTagBaseValue;
//      [btn addTarget:self action:@selector(selectFreeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
//      [btnBgView addSubview:btn];
//      [itemScrollView addSubview:btnBgView];
//      [btnBgView release];
//    }
//    itemScrollView.contentSize = CGSizeMake((60+5)*6, itemScrollView.frame.size.height);
//    itemScrollView.showsHorizontalScrollIndicator = NO;
//    itemScrollView.showsVerticalScrollIndicator = NO;
//    itemScrollView.scrollEnabled = NO;
//    
//    [self addSubview:itemScrollView];
//    [itemScrollView release];
//  }

  UIButton *okBtn = [UIButton buttonWithType:UIButtonTypeCustom];
  [okBtn setTitle:@"确认" forState:UIControlStateNormal];
  okBtn.frame = CGRectMake(self.bounds.size.width - 5 - 45, 10, 45, 30);
  okBtn.titleLabel.font = [UIFont systemFontOfSize:15];
  [okBtn addTarget:self action:@selector(okBtnAction) forControlEvents:UIControlEventTouchUpInside];
  [okBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
  [okBtn setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];
  [okBtn setBackgroundImage:[UIImage stretchImageName:@"honganniu.png"] forState:UIControlStateNormal];
  [okBtn setBackgroundImage:[UIImage stretchImageName:@"honganniu_d.png"] forState:UIControlStateHighlighted];
  [self addSubview:okBtn];
}

//- (NSString *)imageNameWithIndex:(int)index{
//  index += 1;
//  index = MAX(1, index);
//  NSString *fileName = @"";
//  if (IS_IPHONE_5) {
//    fileName = [NSString stringWithFormat:@"mp_bg_%d_ip5.jpg", index];
//  } else {
//    fileName = [NSString stringWithFormat:@"mp_bg_%d.jpg", index];
//  }
//  
//  return fileName;
//}

//- (void)selectFreeBtnAction:(UIButton *)button {
//  if (button.tag == selectedFreeBtnTag) {
//    return;
//  }
//  
//  selectedFreeBtnTag = button.tag;
//  NSString *imageName = [self imageNameWithIndex:button.tag - kFreeBtnTagBaseValue];
//  if ([delegate respondsToSelector:@selector(makePhotoBottomView:didChooseBackgroundImageName:)]) {
//    [delegate makePhotoBottomView:self didChooseBackgroundImageName:imageName];
//  }
//}

- (void)selectCellBtnAction:(UIButton *)button {
  if (button.tag == selectedCellBtnTag) {
    return;
  }
  
  UIButton *selectBtn = (UIButton *)[self viewWithTag:selectedCellBtnTag];
  if ([selectBtn isKindOfClass:[UIButton class]]) {
    selectBtn.selected = NO;
    selectBtn.userInteractionEnabled = YES;
    button.selected = YES;
    button.userInteractionEnabled = NO;
    selectedCellBtnTag = button.tag;
    
    if ([delegate respondsToSelector:@selector(makePhotoBottomView:didSelectedWithIndex:)]) {
      [delegate makePhotoBottomView:self didSelectedWithIndex:selectedCellBtnTag - kCellBtnTagBaseValue];
    }
  }
}

- (void)okBtnAction {
  if ([delegate respondsToSelector:@selector(makePhotoBottomViewDidClickedOkBtn:)]) {
    [delegate makePhotoBottomViewDidClickedOkBtn:self];
  }
}

//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
//  UITouch *touch = [touches anyObject];
//  CGPoint touchPoint = [touch locationInView:self];
//  if (CGRectContainsPoint(cellFrame, touchPoint) ||
//      CGRectContainsPoint(freeFrame, touchPoint)) {
//    
//    if (CGRectContainsPoint(cellFrame, touchPoint)) {
//      type = MakePhoto_Type_Cell;
//    }
//    else {
//      type = MakePhoto_Type_Free;
//    }
//    if ([delegate respondsToSelector:@selector(makePhotoBottomViewDidChangeTypeBtn:)]) {
//      [delegate makePhotoBottomViewDidChangeTypeBtn:self];
//    }
//    [self setNeedsDisplay];
//    [self resetSubView];
//  }
//}



- (void)drawRect:(CGRect)rect {
//  [[UIImage stretchImageName:@"changxing.png"] drawInRect:CGRectMake(0, 0, 140, topHeight)];
//  
//  [[UIColor darkGrayColor] set];
//  
//  CGRect cellDrawFrame = CGRectMake(15, 11, 45, 12);
//  CGRect freeDrawFrame = CGRectMake(cellDrawFrame.origin.x + cellDrawFrame.size.width + 15, cellDrawFrame.origin.y, cellDrawFrame.size.width, cellDrawFrame.size.height);
//  
//  cellFrame = CGRectInset(cellDrawFrame, -6, -4);
//  freeFrame = CGRectInset(freeDrawFrame, -6, -4);
//  
//  if (type == MakePhoto_Type_Cell) {
//    [[UIImage stretchImageName:@"m_dianjizhuangtai.png"] drawInRect:cellFrame];
//  }
//  else {
//    [[UIImage stretchImageName:@"m_dianjizhuangtai.png"] drawInRect:freeFrame];
//  }
//  [@"相格" drawInRect:cellDrawFrame withFont:kSystemFont(11) lineBreakMode:UILineBreakByTruncatingMiddle alignment:NSTextAlignmentCenter];
//  [@"自由拼图" drawInRect:freeDrawFrame withFont:kSystemFont(11) lineBreakMode:UILineBreakByTruncatingMiddle alignment:NSTextAlignmentCenter];
  
  [[UIImage stretchImageName:@"aoxing.png"] drawInRect:CGRectMake(0, 0, rect.size.width, rect.size.height)];
}

- (NSString *)imgStrWithIndex:(int)index {
  NSString *imgStr = nil;
  
  switch (photoNum) {
    case 2:
      switch (index) {
        case 0:
          imgStr = @"zhongxia";
          break;
        case 1:
          imgStr = @"zhizhong";
          break;
        case 2:
          imgStr = @"zhizhongyou";
          break;
        case 3:
          imgStr = @"zhong";
          break;
          
        default:
          break;
      }
      break;
      
    case 3:
      switch (index) {
        case 0:
          imgStr = @"xiangge5";
          break;
        case 1:
          imgStr = @"xiangge7";
          break;
        case 2:
          imgStr = @"xiangge8";
          break;
        case 3:
          imgStr = @"xiangge6";
          break;
          
        default:
          break;
      }
      break;
      
    case 4:
      switch (index) {
        case 0:
          imgStr = @"xiangge9";
          break;
        case 1:
          imgStr = @"xiangge10";
          break;
        case 2:
          imgStr = @"xiangge11";
          break;
        case 3:
          imgStr = @"xiangge12";
          break;
          
        default:
          break;
      }
      break;
      
    default:
      break;
  }
  
  return imgStr;
}

@end

////////////////////////////////////////////////////////////
#pragma MDMakePhotoScrollView -----------------------

@class MDMakePhotoScrollView;

@protocol MDMakePhotoScrollViewDelegate <NSObject>

- (void)makePhotoScrollViewDidStopedDrag:(MDMakePhotoScrollView *)view;

@end

@interface MDMakePhotoScrollView : UIScrollView<UIScrollViewDelegate>

@property (nonatomic, readonly) CGRect originalFrame;
@property (nonatomic, weak) id<MDMakePhotoScrollViewDelegate> dragDelegate;
@property (nonatomic, assign) BOOL isCanDrag;

- (id)initWithImgPath:(NSString *)imgPath;
- (instancetype)initWithImage:(UIImage *)image;
- (void)resetOiginalBoundsWithWidth:(int)width;
- (void)resetFrame:(CGRect)frame;

@end

@interface MDMakePhotoScrollView() {
  UIImageView *photoView;
  CGRect originalFrame_;
  BOOL isCanDrag;
  id<MDMakePhotoScrollViewDelegate> __weak dragDelegate;
}

@end

@implementation MDMakePhotoScrollView
@synthesize dragDelegate;
@synthesize originalFrame;
@synthesize isCanDrag;

- (CGRect)originalFrame {
  return originalFrame_;
}

- (id)initWithImgPath:(NSString *)imgPath {
//  if (imgPath.length == 0) {
//    return nil;
//  }
  
  if (self = [super init]) {
    self.delegate = self;
    photoView = [[UIImageView alloc] initWithImage:[UIImage imageWithContentsOfFile:imgPath]];
    photoView.userInteractionEnabled = YES;
    self.isCanDrag = YES; 
    [self addSubview:photoView];
    self.layer.borderWidth = 2;
    self.layer.borderColor = [UIColor clearColor].CGColor;
  }
  return self;
}

- (instancetype)initWithImage:(UIImage *)image {
    if (self = [super init]) {
        self.delegate = self;
        photoView = [[UIImageView alloc] initWithImage:image];
        photoView.userInteractionEnabled = YES;
        self.isCanDrag = YES;
        [self addSubview:photoView];
        self.layer.borderWidth = 2;
        self.layer.borderColor = [UIColor clearColor].CGColor;
    }
    return self;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView {
  return photoView;
}

- (void)resetOiginalBoundsWithWidth:(int)width {
  int height = photoView.image.size.height * width / photoView.image.size.width;
  self.bounds = CGRectMake(0, 0, width, height);
}

- (void)resetFrame:(CGRect)frame {
  [UIView animateWithDuration:0.5 animations:^ {
    self.frame = frame;
  }];
}

- (void)setFrame:(CGRect)frame {
  if (isCanDrag) {
    if (!CGSizeEqualToSize(frame.size, self.frame.size)) {
      CGFloat imgViewNeedWidth = photoView.image.size.width * frame.size.height / photoView.image.size.height;
      CGFloat imgViewNeedHeight = photoView.image.size.height * frame.size.width / photoView.image.size.width;
      
      if (imgViewNeedWidth > frame.size.width) {
        photoView.frame = CGRectMake(0, 0, imgViewNeedWidth * 2.0f, frame.size.height * 2.0f);
        self.minimumZoomScale = frame.size.height / photoView.bounds.size.height;
      }
      else {
        photoView.frame = CGRectMake(0, 0, frame.size.width * 2.0f, imgViewNeedHeight * 2.0f);
        self.minimumZoomScale = frame.size.width / photoView.bounds.size.width;
      }
      [self setZoomScale:self.minimumZoomScale];
    }
  }
  else {
    photoView.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
    self.contentSize = photoView.frame.size;
  }
  
  [super setFrame:frame];
  originalFrame_ = frame;
}

- (BOOL)touchesShouldCancelInContentView:(UIView *)view {
  return NO;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
  if (!isCanDrag) {
    return;
  }
  self.alpha = 0.5;
  self.layer.borderColor=[[UIColor blueColor] CGColor];
  [[self superview] bringSubviewToFront:self];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
  if (!isCanDrag) {
    return;
  }
  UITouch *touch = [touches anyObject];
  CGPoint currentLocation = [touch locationInView:self.superview];
  self.center = currentLocation;
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
  if (!isCanDrag) {
    return;
  }
  self.alpha = 1;
  self.layer.borderColor=[[UIColor clearColor] CGColor];
  if ([dragDelegate respondsToSelector:@selector(makePhotoScrollViewDidStopedDrag:)]) {
    [dragDelegate makePhotoScrollViewDidStopedDrag:self];
  }
}

@end

////////////////////////////////////////////////////////////
#pragma MDMakeCellPhotoView -----------------------

@interface MDMakeCellPhotoView : UIView <MDMakePhotoScrollViewDelegate>

- (void)changeLayoutWithIndex:(int)index;

@property (weak, nonatomic, readonly) UIImage *resultImage;

@end

#define kSubMakePhotoViewBaseTag 'smpv'

@interface MDMakeCellPhotoView() {
  NSArray *photos;
  int offsetX;
  int offsetY;
  int intervalX;
  int intervalY;
  UIScrollView *scrollBgView;
}

@property (nonatomic, strong) NSArray *photos;
@property (nonatomic, strong) UIScrollView *scrollBgView;

@end

@implementation MDMakeCellPhotoView
@synthesize photos;
@synthesize scrollBgView;

- (id)initWithELCPhotos:(NSArray*)elcPhotos {
  if (self = [super init]) {
    int defaultHeight = kScreenHeight - 20 - 44 - 50;
    int defaultWidth = kScreenWidth * defaultHeight / kScreenHeight;
    offsetX = 0;
    offsetY = 0;
    intervalX = 3;
    intervalY = 3;
    
    self.photos = elcPhotos;
    self.bounds = CGRectMake(0, 0, defaultWidth, defaultHeight);
    self.backgroundColor = [UIColor whiteColor];
    [self addAllSubPhotoView];
    [self changeLayoutWithIndex:0];
  }
  
  return self;
}

- (void)addAllSubPhotoView {
  for (int i = 0; i < [photos count]; i++) {
//    MmdHairChangePhoto *hPhoto = (MmdHairChangePhoto *)[photos safeObjectAtIndex:i];
//    if (hPhoto.imagePath.length == 0) {
//      continue;
//    }
      UIImage *image = photos[i];
    MDMakePhotoScrollView *tmpScrollView = [[MDMakePhotoScrollView alloc] initWithImage:image];
    tmpScrollView.tag = kSubMakePhotoViewBaseTag + i;
    if ([photos count] == 1) {
      [tmpScrollView resetFrame:CGRectMake(offsetX, offsetY, self.bounds.size.width - 2 * offsetX, self.bounds.size.height - 2 * offsetY)];
    }
    
    tmpScrollView.dragDelegate = self;
    [self addSubview:tmpScrollView];
  }
}

- (void)makePhotoScrollViewDidStopedDrag:(MDMakePhotoScrollView *)view {
  for (MDMakePhotoScrollView *scrollView in [self subviews]) {
    if (![scrollView isEqual:view] &&
        CGRectContainsPoint(scrollView.originalFrame, view.center)) {
      CGRect tempFrame = scrollView.originalFrame;
      [scrollView resetFrame:view.originalFrame];
      [view resetFrame:tempFrame];
      
      int tempTag = scrollView.tag;
      scrollView.tag = view.tag;
      view.tag = tempTag;
      
      return;
    }
  }
  [view resetFrame:view.originalFrame];
}

- (void)changeTwoPhotosLayoutWithIndex:(int)index {
  if (index < 0 || index > 4) {
    return;
  }

  CGRect firstFrame = CGRectZero;
  CGRect secondFrame = CGRectZero;
  
  switch (index) {
    case 0:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, self.bounds.size.width - offsetX * 2, (self.bounds.size.height - 2 * offsetY + intervalY ) * 2 / 3);
      secondFrame = CGRectMake(offsetX, offsetY + intervalY + firstFrame.size.height, self.bounds.size.width - offsetX * 2, (self.bounds.size.height - 2 * offsetY - intervalY - firstFrame.size.height));
//      firstFrame = CGRectMake(offsetX, offsetY, self.bounds.size.width - offsetX * 2, (self.bounds.size.height - 2 * offsetY - intervalY ) / 2);
//      secondFrame = CGRectMake(offsetX, offsetY + firstFrame.size.height + intervalY, firstFrame.size.width, firstFrame.size.height);
      break;
    case 1:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, self.bounds.size.height - 2 * offsetY);
      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, firstFrame.size.width, firstFrame.size.height);
//      firstFrame = CGRectMake(offsetX, offsetY, self.bounds.size.width - offsetX * 2, (self.bounds.size.height - 2 * offsetY + intervalY ) * 2 / 3);
//      secondFrame = CGRectMake(offsetX, offsetY + intervalY + firstFrame.size.height, self.bounds.size.width - offsetX * 2, (self.bounds.size.height - 2 * offsetY - intervalY - firstFrame.size.height));
      break;
    case 2:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2/ 3, self.bounds.size.height - 2 * offsetY);
      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 1/ 3, firstFrame.size.height);
//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, self.bounds.size.height - 2 * offsetY);
//      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, firstFrame.size.width, firstFrame.size.height);
      break;
    case 3:
    {
      [self changeSubViewState:NO];
      int offsetTop = offsetY;
      MDMakePhotoScrollView *view1 = [self makePhotoSubViewWithIndex:0];
      MDMakePhotoScrollView *view2 = [self makePhotoSubViewWithIndex:1];
      [view1 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view2 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      
      firstFrame = CGRectMake(offsetX, offsetTop, view1.bounds.size.width, view1.bounds.size.height);
      offsetTop += firstFrame.size.height + intervalY;
      secondFrame = CGRectMake(offsetX, offsetTop, view2.bounds.size.width, view2.bounds.size.height);
      offsetTop += secondFrame.size.height + offsetY;
      self.scrollBgView.contentSize = CGSizeMake(self.bounds.size.width, offsetTop);
    }

//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2/ 3, self.bounds.size.height - 2 * offsetY);
//      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 1/ 3, firstFrame.size.height);
      break;
    default:
      break;
  }
  
  [[self makePhotoSubViewWithIndex:0] resetFrame:firstFrame];
  [[self makePhotoSubViewWithIndex:1] resetFrame:secondFrame];
}

- (MDMakePhotoScrollView *)makePhotoSubViewWithIndex:(int)index {
  MDMakePhotoScrollView *view = (MDMakePhotoScrollView *)[self viewWithTag:kSubMakePhotoViewBaseTag + index];
  if ([view isKindOfClass:[MDMakePhotoScrollView class]]) {
    return view;
  }
  else {
    return nil;
  }
}

- (void)changeSpecialThreePhotosLayout {
  
}

- (void)changeThreePhotosLayoutWithIndex:(int)index {
  if (index < 0 || index > 4) {
    return;
  }
  
  CGRect firstFrame = CGRectZero;
  CGRect secondFrame = CGRectZero;
  CGRect thirdFrame = CGRectZero;
  
  switch (index) {
    case 0:
      firstFrame = CGRectMake(offsetX, offsetY, self.bounds.size.width - 2 * offsetX, (self.bounds.size.height - 2 * offsetY - intervalY) / 2);
      secondFrame = CGRectMake(offsetX, offsetY + intervalY + firstFrame.size.height, (self.bounds.size.width - offsetX * 2 - intervalX) / 2, firstFrame.size.height);
      thirdFrame = CGRectMake(offsetX + intervalX + secondFrame.size.width, secondFrame.origin.y, secondFrame.size.width, secondFrame.size.height);
      [self changeSubViewState:YES];
      break;
    case 1:
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, self.bounds.size.height - 2 * offsetY);
      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width, (firstFrame.size.height - intervalY) / 3);
      thirdFrame = CGRectMake(secondFrame.origin.x, offsetY + secondFrame.size.height + intervalY, secondFrame.size.width, secondFrame.size.height * 2);
//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, self.bounds.size.height - 2 * offsetY);
//      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width, (firstFrame.size.height - intervalY) / 2);
//      thirdFrame = CGRectMake(secondFrame.origin.x, offsetY + secondFrame.size.height + intervalY, secondFrame.size.width, secondFrame.size.height);
//      [self changeSubViewState:YES];
      break;
    case 2:
    {
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2/ 3, (self.bounds.size.height - 2 * offsetY - intervalY) * 2 / 3);
      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width / 2, firstFrame.size.height);
      thirdFrame = CGRectMake(offsetX, offsetY + intervalY + secondFrame.size.height, self.bounds.size.width - 2 * offsetX, secondFrame.size.height / 2);
      [self changeSubViewState:YES];
    }
      
     // self.contentSize = CGSizeMake(<#CGFloat width#>, <#CGFloat height#>)
      
//      firstFrame = CGRectMake(offsetX, offsetY, self.bounds.size.width - 2 * offsetX, (self.bounds.size.height - (offsetY + intervalY) * 2) / 3);
//      secondFrame = CGRectMake(offsetX, offsetY + firstFrame.size.height + intervalY, firstFrame.size.width, firstFrame.size.height);
//      thirdFrame = CGRectMake(offsetX, offsetY + (firstFrame.size.height + intervalY) * 2, firstFrame.size.width, firstFrame.size.height);
      
      //old
//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, self.bounds.size.height - 2 * offsetY);
//      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width, (firstFrame.size.height - intervalY) / 3);
//      thirdFrame = CGRectMake(secondFrame.origin.x, offsetY + secondFrame.size.height + intervalY, secondFrame.size.width, secondFrame.size.height * 2);
      break;
    case 3:
    {
      [self changeSubViewState:NO];
      int offsetTop = offsetY;
      MDMakePhotoScrollView *view1 = [self makePhotoSubViewWithIndex:0];
      MDMakePhotoScrollView *view2 = [self makePhotoSubViewWithIndex:1];
      MDMakePhotoScrollView *view3 = [self makePhotoSubViewWithIndex:2];
      [view1 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view2 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view3 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      
      firstFrame = CGRectMake(offsetX, offsetTop, view1.bounds.size.width, view1.bounds.size.height);
      offsetTop += firstFrame.size.height + intervalY;
      secondFrame = CGRectMake(offsetX, offsetTop, view2.bounds.size.width, view2.bounds.size.height);
      offsetTop += secondFrame.size.height + intervalY;
      
      thirdFrame = CGRectMake(offsetX, offsetTop, view3.bounds.size.width, view3.bounds.size.height);
      
      offsetTop += thirdFrame.size.height + offsetY;
      self.scrollBgView.contentSize = CGSizeMake(self.bounds.size.width, offsetTop);
    }
//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2/ 3, (self.bounds.size.height - 2 * offsetY - intervalY) * 2 / 3);
//      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width / 2, firstFrame.size.height);
//      thirdFrame = CGRectMake(offsetX, offsetY + intervalY + secondFrame.size.height, self.bounds.size.width - 2 * offsetX, secondFrame.size.height / 2);
//      [self changeSubViewState:YES];
      break;
    default:
      break;
  }
  
  [[self makePhotoSubViewWithIndex:0] resetFrame:firstFrame];
  [[self makePhotoSubViewWithIndex:1] resetFrame:secondFrame];
  [[self makePhotoSubViewWithIndex:2] resetFrame:thirdFrame];
}

- (void)changeSubViewState:(BOOL)isCanDrag {
  MDMakePhotoScrollView *view1 = [self makePhotoSubViewWithIndex:0];
  MDMakePhotoScrollView *view2 = [self makePhotoSubViewWithIndex:1];
  MDMakePhotoScrollView *view3 = [self makePhotoSubViewWithIndex:2];
  MDMakePhotoScrollView *view4 = [self makePhotoSubViewWithIndex:3];
  
  [view1 removeFromSuperview];
  [view2 removeFromSuperview];
  [view3 removeFromSuperview];
  [view4 removeFromSuperview];
  
  if (isCanDrag) {
    [self addSubview:view1];
    [self addSubview:view2];
    [self addSubview:view3];
    [self addSubview:view4];
    [self.scrollBgView removeFromSuperview];
    self.scrollBgView = nil;
  }
  else {
    self.scrollBgView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height)];
    [self.scrollBgView addSubview:view1];
    [self.scrollBgView addSubview:view2];
    [self.scrollBgView addSubview:view3];
    [self.scrollBgView addSubview:view4];
    [self addSubview:self.scrollBgView];
  }
  
  view1.isCanDrag = isCanDrag;
  view2.isCanDrag = isCanDrag;
  view3.isCanDrag = isCanDrag;
  view4.isCanDrag = isCanDrag;
}

- (void)changeFourPhotosLayoutWithIndex:(int)index {
  if (index < 0 || index > 4) {
    return;
  }
  
  CGRect firstFrame = CGRectZero;
  CGRect secondFrame = CGRectZero;
  CGRect thirdFrame = CGRectZero;
  CGRect fourthFrame = CGRectZero;
  
  switch (index) {
    case 0:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) / 2, (self.bounds.size.height - 2 * offsetY - intervalY) / 2);
      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width, firstFrame.size.height);
      thirdFrame = CGRectMake(offsetX, offsetY + intervalY + secondFrame.size.height, secondFrame.size.width, secondFrame.size.height);
      fourthFrame = CGRectMake(secondFrame.origin.x, thirdFrame.origin.y, thirdFrame.size.width, thirdFrame.size.height);
      break;
    case 1:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2 / 3, (self.bounds.size.height - 2 * offsetY - intervalY) / 3);
      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, firstFrame.size.width / 2, firstFrame.size.height * 2);
      thirdFrame = CGRectMake(offsetX, offsetY + intervalY + firstFrame.size.height, firstFrame.size.width, secondFrame.size.height);
      fourthFrame = CGRectMake(secondFrame.origin.x, offsetY + intervalY + secondFrame.size.height, secondFrame.size.width, firstFrame.size.height);
      break;
    case 2:
      [self changeSubViewState:YES];
      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - 2 * offsetX - intervalX) * 2 / 3, self.bounds.size.height - 2 * offsetY);
      secondFrame = CGRectMake(offsetX + firstFrame.size.width + intervalX, offsetY, firstFrame.size.width / 2, (firstFrame.size.height - 2 * intervalY) / 3);
      thirdFrame = CGRectMake(secondFrame.origin.x, offsetY + secondFrame.size.height + intervalY, secondFrame.size.width, secondFrame.size.height);
      fourthFrame = CGRectMake(thirdFrame.origin.x, offsetY + (thirdFrame.size.height + intervalY) * 2, thirdFrame.size.width, thirdFrame.size.height);
      break;
    case 3:
      
    {
      [self changeSubViewState:NO];
      int offsetTop = offsetY;
      MDMakePhotoScrollView *view1 = [self makePhotoSubViewWithIndex:0];
      MDMakePhotoScrollView *view2 = [self makePhotoSubViewWithIndex:1];
      MDMakePhotoScrollView *view3 = [self makePhotoSubViewWithIndex:2];
      MDMakePhotoScrollView *view4 = [self makePhotoSubViewWithIndex:3];
      [view1 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view2 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view3 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      [view4 resetOiginalBoundsWithWidth:self.bounds.size.width - offsetX * 2];
      
      firstFrame = CGRectMake(offsetX, offsetTop, view1.bounds.size.width, view1.bounds.size.height);
      offsetTop += firstFrame.size.height + intervalY;
      secondFrame = CGRectMake(offsetX, offsetTop, view2.bounds.size.width, view2.bounds.size.height);
      offsetTop += secondFrame.size.height + intervalY;
      
      thirdFrame = CGRectMake(offsetX, offsetTop, view3.bounds.size.width, view3.bounds.size.height);
      
      offsetTop += thirdFrame.size.height + intervalY;
      
      fourthFrame = CGRectMake(offsetX, offsetTop, view4.bounds.size.width, view4.bounds.size.height);
      offsetTop += fourthFrame.size.height + offsetY;
      self.scrollBgView.contentSize = CGSizeMake(self.bounds.size.width, offsetTop);
    }

//      firstFrame = CGRectMake(offsetX, offsetY, (self.bounds.size.width - (offsetX + intervalX) * 2) / 3, (self.bounds.size.height - 2 * offsetY - intervalY) / 2);
//      secondFrame = CGRectMake(offsetX + intervalX + firstFrame.size.width, offsetY, firstFrame.size.width, firstFrame.size.height);
//      thirdFrame = CGRectMake(offsetX + (intervalX + firstFrame.size.width) * 2, offsetY, secondFrame.size.width, secondFrame.size.height);
//      fourthFrame = CGRectMake(offsetX, offsetY + intervalY + thirdFrame.size.height, self.bounds.size.width - offsetX * 2, thirdFrame.size.height);
      break;
    default:
      break;
  }
  
  [[self makePhotoSubViewWithIndex:0] resetFrame:firstFrame];
  [[self makePhotoSubViewWithIndex:1] resetFrame:secondFrame];
  [[self makePhotoSubViewWithIndex:2] resetFrame:thirdFrame];
  [[self makePhotoSubViewWithIndex:3] resetFrame:fourthFrame];
}



- (void)changeLayoutWithIndex:(int)index {
  int photoSum = [photos count];
  if (photoSum <= 1 || photoSum > 4) {
    return;
  }
  
  switch (photoSum) {
    case 2:
      [self changeTwoPhotosLayoutWithIndex:index];
      break;
    case 3:
      [self changeThreePhotosLayoutWithIndex:index];
      break;
    case 4:
      [self changeFourPhotosLayoutWithIndex:index];
      break;
    default:
      break;
  }
}

- (UIImage *)resultImage {
  
  UIImage *viewImage = nil;
  
  if (self.scrollBgView == nil) {
    UIGraphicsBeginImageContextWithOptions(self.bounds.size, YES, 3);
    [self.layer renderInContext:UIGraphicsGetCurrentContext()];
    viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
  }
  else {
    UIGraphicsBeginImageContextWithOptions(self.scrollBgView.contentSize, YES, 3);
      scrollBgView.contentOffset = CGPointZero;
      scrollBgView.frame = CGRectMake(0, 0, scrollBgView.contentSize.width, scrollBgView.contentSize.height);
      NSLog(@"%@", NSStringFromCGRect(scrollBgView.frame));
      
      [scrollBgView.layer renderInContext: UIGraphicsGetCurrentContext()];
      viewImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
  }
  
  NSLog(@"imgsize == %@", NSStringFromCGSize(viewImage.size));
  return viewImage;
}
@end

//////////////////////////////////////////////////////////////
//#pragma MDMakeFreePhotoView -----------------------
//
//static double radiansq(float degrees) {
//  return ( degrees * M_PI_2 ) / 180.0;
//}
//
//@interface MDMakeFreePhotoView : UIImageView<TouchImageViewDelegate>
//
//- (id)initWithELCPhotos:(NSArray*)elcPhotos;
//
//@property (nonatomic, readonly) UIImage *resultImage;
//
//@end
//
//@implementation MDMakeFreePhotoView
//
//- (id)initWithELCPhotos:(NSArray*)elcPhotos {
//  if ([self initWithFrame:CGRectMake(0, 0, kScreenWidth, kScreenHeight - 20 - 44)]) {
//    
//    self.userInteractionEnabled = YES;
//    NSInteger index = 0;
//    CGFloat top = 30;
//    for (MmdHairChangePhoto *photo in elcPhotos) {
//      UIImage *image = [UIImage imageWithContentsOfFile:photo.imagePath];
//      TouchImageView *touchView = [[TouchImageView alloc] initWithFrame:CGRectMake(0, 0, 130, 130*(image.size.height/image.size.width))];
//      
//      touchView.layer.borderColor = [UIColor whiteColor].CGColor;
//      touchView.layer.borderWidth = 2.0;
//      touchView.layer.cornerRadius = 3;
//      touchView.clipsToBounds = YES;
//      
//      touchView.top = top;
//      touchView.delegate = self;
//      
//      if (fmod(index, 2) == 0) {
//        int value = (arc4random() % 50) + 30;
//        touchView.left = value;
//        touchView.transform = CGAffineTransformMakeRotation(-radiansq(value));
//      }
//      else {
//        int value = (arc4random() % 110) + 90;
//        touchView.left = value;
//        touchView.transform = CGAffineTransformMakeRotation(radiansq(value-60));
//        top += 100+(arc4random()%20) ;
//      }
//      
//      [touchView setImage:image];
//      index ++;
//      
//      //[touchView setCanToFront:YES];
//      touchView.originalTransform = touchView.transform;
//      [touchView setCanTouch:YES];
//      [self addSubview:touchView];
//      [touchView release];
//    }
//  }
//  
//  return self;
//}
//
//- (void)touchImageView:(TouchImageView *)view TapCount:(NSInteger)count{
//  if (count>=1) {
//    [self bringSubviewToFront:view];
//  }
//}
//
//- (UIImage *)resultImage {
//  UIGraphicsBeginImageContextWithOptions(self.bounds.size, YES, 0.0);
//  [self.layer renderInContext:UIGraphicsGetCurrentContext()];
//  UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
//  UIGraphicsEndImageContext();
//  return resultingImage;
//}
//
//@end

////////////////////////////////////////////////////////////
#pragma MDNewMakePhotoViewController -----------------------

@interface MDNewMakePhotoViewController ()<MDMakePhotoBottomViewDelegate> {
  NSArray *photos;
  MDMakeCellPhotoView *makeCellPhotoView;
  //MDMakeFreePhotoView *makeFreePhotoView;
  MDMakePhotoBottomView *makePhotoBottomView;
  id<MDNewMakePhotoViewControllerDelegate> __weak delegate;
  BOOL isShareFromHairChange;
}

@property (nonatomic, strong) NSArray *photos;
@property (nonatomic, strong) MDMakeCellPhotoView *makeCellPhotoView;
//@property (nonatomic, retain) MDMakeFreePhotoView *makeFreePhotoView;
@property (nonatomic, strong) MDMakePhotoBottomView *makePhotoBottomView;

@end

@implementation MDNewMakePhotoViewController
@synthesize photos;
@synthesize makeCellPhotoView;
//@synthesize makeFreePhotoView;
@synthesize makePhotoBottomView;
@synthesize delegate;

//- (id)initWithManager:(ChangeHairManager *)mng photos:(NSArray*)photoArr{
//  if (self = [super initWithManager:mng]) {
//    logEvent(@"HAIR_CHANGE_PUZZLE");
//    self.photos = photoArr;
//    isShareFromHairChange = YES;
//  }
//  
//  return self;
//}

- (instancetype)initWithPhotos:(NSArray *)photos {
    if (self = [super init]) {
        self.photos = photos;
    }
    return self;
}

//- (id)initWithELCPhotos:(NSArray*)elcPhotos {
//  if (self = [super init]) {
//    NSMutableArray *tmpArr = [NSMutableArray arrayWithCapacity:elcPhotos.count];
//    for (ELCPhoto *photo in elcPhotos) {
//      MmdHairChangePhoto *hPhoto = [[MmdHairChangePhoto alloc] init];
//      hPhoto.imagePath = photo.imagePath;
//      [tmpArr addSafeObject:hPhoto];
//    }
//    isShareFromHairChange = NO;
//    self.photos = tmpArr;
//  }
//
//  return self;
//}

- (void)dealloc {
#if DEBUG_OOM
  DLog(@"%@ dealloc", [[self class] description]);
#endif
}

- (void)viewDidLoad {
  [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
//  self.view.backgroundColor = TABLE_BACKGROUND_COLOR;
//  [self setMMDTitle:_(@"TEXT_JIGSAW_PUZZLE_SHARE")];
//  [self setMMDBackItem];
  if (!isShareFromHairChange) {
   // [self setMMDRightItemWithTitle:_(@"TEXT_CANCEL") action:@selector(cancelAction)];
  }
  
  self.makeCellPhotoView = [[MDMakeCellPhotoView alloc] initWithELCPhotos:self.photos];
  makeCellPhotoView.frame = CGRectMake((self.view.bounds.size.width - makeCellPhotoView.bounds.size.width) / 2, 0, makeCellPhotoView.bounds.size.width, makeCellPhotoView.bounds.size.height);
  [self.view addSubview:self.makeCellPhotoView];
  
  self.makePhotoBottomView = [[MDMakePhotoBottomView alloc] initWithPhotoNum:[self.photos count]];
  self.makePhotoBottomView.delegate = self;
  makePhotoBottomView.frame = CGRectMake(0, self.view.bounds.size.height - 44 - makePhotoBottomView.bounds.size.height, makePhotoBottomView.bounds.size.width, makePhotoBottomView.bounds.size.height);
  [self.view addSubview:makePhotoBottomView];
  
  //[self makePhotoBottomViewDidChangeTypeBtn:self.makePhotoBottomView];
}

- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}

- (void)cancelAction {
  if ([delegate respondsToSelector:@selector(newMakePhotoViewControllerDidCancel:)]) {
    [delegate newMakePhotoViewControllerDidCancel:self];
    [self.navigationController popToRootViewControllerAnimated:NO];
  }
}

#pragma mark MDMakePhotoBottomView Delegate ------

- (void)makePhotoBottomView:(MDMakePhotoBottomView *)view didSelectedWithIndex:(int)intdex {
  [self.makeCellPhotoView changeLayoutWithIndex:intdex];
}

- (void)makePhotoBottomViewDidClickedOkBtn:(MDMakePhotoBottomView *)view {
    UIImage *resultImage = nil;
//  if (view.type == MakePhoto_Type_Cell) {
    resultImage = [self.makeCellPhotoView resultImage];
//  }
//  else if (view.type == MakePhoto_Type_Free) {
//    resultImage = [self.makeFreePhotoView resultImage];
//  }
  
  if (resultImage) {
    if (isShareFromHairChange) {
//      self.toShareImagePath = [self.chManager createImageWithImage:resultImage imageName:@"share.png"];
//      self.toShareImage = resultImage;
//      self.toShareText = [super shareText];
//      [self postHairChangeImage];
    }
    else {
      if ([delegate respondsToSelector:@selector(newMakePhotoViewController:didFinishedMakePhoto:)]) {
        [delegate newMakePhotoViewController:self didFinishedMakePhoto:resultImage];
      }
    }
  }
}

//- (void)makePhotoBottomViewDidChangeTypeBtn:(MDMakePhotoBottomView *)view {
//  if (view.type == MakePhoto_Type_Cell) {
//    if (self.makeCellPhotoView == nil) {
//      self.makeCellPhotoView = [[[MDMakeCellPhotoView alloc] initWithELCPhotos:self.photos] autorelease];
//      makeCellPhotoView.frame = CGRectMake((self.view.bounds.size.width - makeCellPhotoView.bounds.size.width) / 2, 0, makeCellPhotoView.bounds.size.width, makeCellPhotoView.bounds.size.height);
//    }
//    [self.makeFreePhotoView removeFromSuperview];
//    [self.view insertSubview:self.makeCellPhotoView belowSubview:self.makePhotoBottomView];
//  }
//  else if (view.type == MakePhoto_Type_Free) {
//    if (self.makeFreePhotoView == nil) {
//      self.makeFreePhotoView = [[[MDMakeFreePhotoView alloc] initWithELCPhotos:self.photos] autorelease];
//      self.makeFreePhotoView.image = [UIImage imageNamed:self.makePhotoBottomView.defaultImgName];
//    }
//    [self.makeCellPhotoView removeFromSuperview];
//        [self.view insertSubview:self.makeFreePhotoView belowSubview:self.makePhotoBottomView];
//  }
//}

//- (void)makePhotoBottomView:(MDMakePhotoBottomView *)view didChooseBackgroundImageName:(NSString *)imgName {
//  self.makeFreePhotoView.image = [UIImage imageNamed:imgName];
//}

@end
