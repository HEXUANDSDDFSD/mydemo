//
//  UIImage+Additions.m
//  meimeidou
//
//  Created by jimzhao on 12-9-13.
//  Copyright (c) 2012年 meimeidou. All rights reserved.
//

#import "UIImage+Additions.h"
#import "UIImage+Resize.h"
// Return a bitmap context using alpha/red/green/blue byte values
CGContextRef CreateRGBABitmapContext (CGImageRef inImage)
{
	CGContextRef context = NULL;
	CGColorSpaceRef colorSpace;
	void *bitmapData;
	int bitmapByteCount;
	int bitmapBytesPerRow;
	size_t pixelsWide = CGImageGetWidth(inImage);
	size_t pixelsHigh = CGImageGetHeight(inImage);
	bitmapBytesPerRow	= (pixelsWide * 4);
	bitmapByteCount	= (bitmapBytesPerRow * pixelsHigh);
	colorSpace = CGColorSpaceCreateDeviceRGB();
	if (colorSpace == NULL)
	{
		fprintf(stderr, "Error allocating color space\n"); return NULL;
	}
	// allocate the bitmap & create context
	bitmapData = malloc( bitmapByteCount );
	if (bitmapData == NULL)
	{
		fprintf (stderr, "Memory not allocated!");
		CGColorSpaceRelease( colorSpace );
		return NULL;
	}
	context = CGBitmapContextCreate (bitmapData,
                                     pixelsWide,
                                     pixelsHigh,
                                     8,
                                     bitmapBytesPerRow,
                                     colorSpace,
                                     kCGImageAlphaPremultipliedLast);
	if (context == NULL)
	{
		free (bitmapData);
		fprintf (stderr, "Context not created!");
	}
	CGColorSpaceRelease( colorSpace );
	return context;
}


// Return Image Pixel data as an RGBA bitmap
unsigned char *RequestImagePixelData(UIImage *inImage)
{
	CGImageRef img = [inImage CGImage];
	CGSize size = [inImage size];
	CGContextRef cgctx = CreateRGBABitmapContext(img);
	
	if (cgctx == NULL)
		return NULL;
	
	CGRect rect = {{0,0},{size.width, size.height}};
	CGContextDrawImage(cgctx, rect, img);
	unsigned char *data = CGBitmapContextGetData (cgctx);
	CGContextRelease(cgctx);
	return data;
}


@implementation UIImage(Additions)

+ (UIImage*)blackWhite:(UIImage*)inImage
{
	unsigned char *imgPixel = RequestImagePixelData(inImage);
	CGImageRef inImageRef = [inImage CGImage];
	GLuint w = CGImageGetWidth(inImageRef);
	GLuint h = CGImageGetHeight(inImageRef);
	
	int wOff = 0;
	int pixOff = 0;
	
	for(GLuint y = 0;y< h;y++)
	{
		pixOff = wOff;
		
		for (GLuint x = 0; x<w; x++)
		{
			//int alpha = (unsigned char)imgPixel[pixOff];
			int red = (unsigned char)imgPixel[pixOff];
			int green = (unsigned char)imgPixel[pixOff+1];
			int blue = (unsigned char)imgPixel[pixOff+2];
			
			int bw = (int)((red+green+blue)/3.0);
			
			imgPixel[pixOff] = bw;
			imgPixel[pixOff+1] = bw;
			imgPixel[pixOff+2] = bw;
			
			pixOff += 4;
		}
		wOff += w * 4;
	}
	
	NSInteger dataLength = w*h* 4;
	CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, imgPixel, dataLength, NULL);
	// prep the ingredients
	int bitsPerComponent = 8;
	int bitsPerPixel = 32;
	int bytesPerRow = 4 * w;
	CGColorSpaceRef colorSpaceRef = CGColorSpaceCreateDeviceRGB();
	CGBitmapInfo bitmapInfo = kCGBitmapByteOrderDefault;
	CGColorRenderingIntent renderingIntent = kCGRenderingIntentDefault;
	
	// make the cgimage
	CGImageRef imageRef = CGImageCreate(w, h,
                                        bitsPerComponent,
                                        bitsPerPixel,
                                        bytesPerRow,
                                        colorSpaceRef,
                                        bitmapInfo,
                                        provider,
                                        NULL, NO, renderingIntent);
	
	UIImage *my_Image = [UIImage imageWithCGImage:imageRef];
	
	CFRelease(imageRef);
	CGColorSpaceRelease(colorSpaceRef);
	CGDataProviderRelease(provider);
	return my_Image;
}

+ (UIImage *)stretchImageName:(NSString*)imageName {
  UIImage *image = [UIImage imageNamed:imageName];
  return [image stretchableImageWithLeftCapWidth:image.size.width/2 topCapHeight:image.size.height/2];
}

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize cropRect:(CGRect)cropRect {
  UIImage *newImage = nil;
//  newImage = [self resizedImageWithContentMode:UIViewContentModeScaleAspectFit
//                                        bounds:targetSize
//                          interpolationQuality:kCGInterpolationMedium
//                                      cropRect:cropRect];
  return newImage;
}


- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize {
  return [self imageByScalingAndCroppingForSize:targetSize cropRect:CGRectZero];
}

- (UIImage *)imageAtRect:(CGRect)rect {
  //    NSLog(@"image width==%.2f, height==%.2f, cropRect==%@", self.size.width,self.size.height,NSStringFromCGRect(rect));
  CGImageRef imageRef = CGImageCreateWithImageInRect([self CGImage], rect);
  UIImage* subImage = [UIImage imageWithCGImage: imageRef];
  CGImageRelease(imageRef);
  
  return subImage;
}

- (UIImage*)JPEGImageWithMaxImageBytes:(unsigned long long)length {
  if (length <= 0) {
    length = 1024*1024*2;
  }
  
  UIImage *retImg = nil;
  for (float quality = 0.8; quality > 0.1; quality-=0.1) {
     NSData *jpegData = UIImageJPEGRepresentation(self, quality);
    if ([jpegData length]<=length) {
      retImg = [UIImage imageWithData:jpegData];
      break;
    }
  }
  
  return retImg;
}

@end
