//
//  AppDelegate.h
//  PhotoProcesser
//
//  Created by hexuan on 2018/5/13.
//  Copyright © 2018年 hexuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

