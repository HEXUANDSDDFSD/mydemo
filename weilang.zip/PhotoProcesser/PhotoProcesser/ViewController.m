//
//  ViewController.m
//  PhotoProcesser
//
//  Created by hexuan on 2018/5/13.
//  Copyright © 2018年 hexuan. All rights reserved.
//

#import "ViewController.h"
#import <Photos/Photos.h>
#import "MDNewMakePhotoViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)onHitChoosePhoto:(id)sender {
    NSMutableArray *imageList = [NSMutableArray array];
    for (int i = 0; i < 4; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%d.jpg",i + 1]];
        [imageList addObject:image];
    }
    MDNewMakePhotoViewController *ctr = [[MDNewMakePhotoViewController alloc] initWithPhotos:imageList];
    [self presentViewController:ctr animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
