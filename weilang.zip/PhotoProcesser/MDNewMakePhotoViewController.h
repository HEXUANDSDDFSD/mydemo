//
//  MDNewMakePhotoViewController.h
//  meimeidou
//
//  Created by Hexuan on 13-4-9.
//  Copyright (c) 2013年 meimeidou. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "HairChangeBaseController.h"

@class MDNewMakePhotoViewController;

@protocol MDNewMakePhotoViewControllerDelegate <NSObject>

@optional
- (void)newMakePhotoViewController:(MDNewMakePhotoViewController *)ctr didFinishedMakePhoto:(UIImage*)img;
- (void)newMakePhotoViewControllerDidCancel:(MDNewMakePhotoViewController *)ctr;

@end

@interface MDNewMakePhotoViewController : UIViewController

@property (nonatomic, weak) id<MDNewMakePhotoViewControllerDelegate> delegate;

- (id)initWithELCPhotos:(NSArray*)elcPhotos;
- (id)initWithPhotos:(NSArray*)photos;
//- (id)initWithManager:(ChangeHairManager *)mng photos:(NSArray*)photoArr;

@end
