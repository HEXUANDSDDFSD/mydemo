//
//  UIImage+Additions.h
//  meimeidou
//
//  Created by jimzhao on 12-9-13.
//  Copyright (c) 2012年 meimeidou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage(Additions)

+ (UIImage *)stretchImageName:(NSString*)imageName;

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize;

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize cropRect:(CGRect)cropRect;

- (UIImage *)imageAtRect:(CGRect)rect;

- (UIImage*)JPEGImageWithMaxImageBytes:(unsigned long long)length;

+ (UIImage*)blackWhite:(UIImage*)inImage;

@end
